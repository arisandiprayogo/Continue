/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgcontinue;

/**
 *
 * @author ACER
 */
public class Break_Continue {
      public static void main(String[] args){
        for(int w=2; w<7; w++){
            if(w == 2){
                break;
            }else{
            System.out.println(w);
            }
        }
    }
}
